This grid system is has not been updated in over a year. I learnt a lot making it, but as a result, I didn't *need* to use it. Therefore the impetus to maintain it has not been there.

Lots of people seem to like it, so I've left it available to download. Fork, fix, change, use. Or don't.